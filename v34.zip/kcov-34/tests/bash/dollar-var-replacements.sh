#/bin/bash
fname='.A'
echo ${fname}
fname="${fname#.}"
echo ${fname}
