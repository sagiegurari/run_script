#! /usr/bin/env bash

for ((i=0; i != 1000; ++i)); do
  echo "$i"
done
