#!/bin/sh

# This do not shows up in coverage report
echo "foo from sh"
