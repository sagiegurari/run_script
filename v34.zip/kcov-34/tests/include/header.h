#ifndef HEADER_H
#define HEADER_H

#if defined(__cplusplus)
extern "C" {
#endif

void tjoho(int a);
void tjoho2(int a);

#if defined(__cplusplus)
};
#endif

#endif


