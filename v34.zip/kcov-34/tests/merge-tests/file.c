int vobb(void)
{
	return 15;
}

int mibb(void)
{
	return 27;
}
